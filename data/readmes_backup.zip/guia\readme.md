# 🌌 Catálogo de Repositorios de IA & Automatización

Catálogo operativo de los **156 repositorios** locales del workspace, diseñado para **entender, comparar, elegir y combinar** repos rápido.

---

> 🤖 **¿Eres un agente de IA?** Empieza por [`AGENTS.md`](../AGENTS.md) y [`INDICE_IA.json`](../INDICE_IA.json) — están optimizados para decidir con pocos tokens. Esta guía es la versión humana, dividida por categoría.

---

## 🧭 Cómo usar esta guía

Hay **tres formas de leerla** según lo que necesites:

| Si quieres… | Ve a… |
|---|---|
| **Barrer todo de un vistazo** y filtrar candidatos | La **tabla de escaneo** al inicio de cada categoría |
| **Decidir entre repos parecidos** (¿whisper o whisperX?) | Las **comparativas "¿cuál elegir?"** dentro de cada categoría |
| **Montar algo end-to-end** combinando varios | Las [**Recetas de integración**](#-recetas-de-integración-stacks-listos) |

> Cada ficha incluye un campo **Combina con** que enlaza a repos complementarios: ese es el hilo para descubrir integraciones sin salir de la ficha.

### Leyenda de badges

Cada ficha abre con una línea **Etiquetas:** que nombra cada valor — `Ejecución <x> · [MCP 🔌 ·] Rol <y> · Setup <z>`:

- **Ejecución:** 🏠 local-first · ☁️ API/cloud · 🔀 híbrido (local o API)
- **MCP:** 🔌 expone o consume Model Context Protocol
- **Rol:** ⚙️ plataforma · 🧩 motor/runtime · 📚 librería/SDK · 🎨 skill/prompt · 📂 directorio/recurso · 🖥️ app/UI
- **Setup:** 🟢 fácil (CLI/instalar) · 🟡 medio (config/servicios) · 🔴 pesado (GPU/infra/self-host)

---

## 📂 Mapa de categorías


| # | Categoría | Repos | Para qué |
|---|---|---|---|
| 1 | [Automatización, Mensajería & CRM](01-automatizacion-mensajeria-crm.md#1-automatización-mensajería--crm) | 12 | WhatsApp, workflows, CRM, email, notificaciones |
| 2 | [Skills, Prompts & Guías de Agente](02-skills-prompts-guias-de-agente.md#2-skills-prompts--guías-de-agente) | 21 | Habilidades `SKILL.md`, playbooks, calidad de prompts |
| 3 | [Frameworks & Orquestación de Agentes](03-frameworks-orquestacion-de-agentes.md#3-frameworks--orquestación-de-agentes) | 18 | Multiagente, research autónomo, low-code de IA |
| 4 | [Scraping, Búsqueda & Research Web](04-scraping-busqueda-research-web.md#4-scraping-búsqueda--research-web) | 14 | Crawling, extracción, navegación con LLM |
| 5 | [MCP & Conectividad](05-mcp-conectividad.md#5-mcp--conectividad) | 7 | Servidores/clientes MCP, APIs públicas |
| 6 | [Memoria, LLM Ops & Observabilidad](06-memoria-llm-ops-observabilidad.md#6-memoria-llm-ops--observabilidad) | 10 | Memoria de agentes, gateways, trazas, logging |
| 7 | [Inteligencia de Código, Datos & Entrenamiento](07-inteligencia-de-codigo-datos-entrenamiento.md#7-inteligencia-de-código-datos--entrenamiento) | 13 | Indexar repos, grafos, entrenar modelos desde cero |
| 8 | [Workspaces de IA Local & Notebooks](08-workspaces-de-ia-local-notebooks.md#8-workspaces-de-ia-local--notebooks) | 5 | Entornos privados todo-en-uno, NotebookLM |
| 9 | [Diseño, UI & Frontend](09-diseno-ui-frontend.md#9-diseño-ui--frontend) | 15 | Diseño asistido, libs de componentes, animación, 3D |
| 10 | [Analítica & Visualización](10-analitica-visualizacion.md#10-analítica--visualización) | 7 | Product analytics, dashboards, gráficos |
| 11 | [Generación de Imagen & Visión](11-generacion-de-imagen-vision.md#11-generación-de-imagen--visión) | 15 | Difusión, control, restauración, rostros |
| 12 | [Audio, Voz & Video](12-audio-voz-video.md#12-audio-voz--video) | 15 | STT, TTS, edición y render de video |
| 13 | [Documentos & Presentaciones](13-documentos-presentaciones.md#13-documentos--presentaciones) | 4 | Conversión a Markdown, PPTX, PDF, slides |

> Cada repo vive en **una** categoría; los cruces se resuelven con "Combina con". Excluidos por ser propios: `Binarias_Labs_C21`, `Binarias_Labs_Pruebas`.

---

## 🔗 Recetas de integración (stacks listos)

Combos end-to-end que unen varios repos. Útiles cuando un repo solo no resuelve el flujo completo.

### 🟢 1. Bot de WhatsApp con IA
**Objetivo:** atención/ventas automatizada por WhatsApp con un agente LLM.
**Stack:** [evolution-api](01-automatizacion-mensajeria-crm.md#-evolution-api) (canal WhatsApp) → [n8n](01-automatizacion-mensajeria-crm.md#-n8n) (orquestación) + [n8n-mcp](05-mcp-conectividad.md#-n8n-mcp) y [n8n-skills](02-skills-prompts-guias-de-agente.md#-n8n-skills) (que Claude construya los flujos) → LLM → [chatwoot](01-automatizacion-mensajeria-crm.md#-chatwoot) (handoff a humano) + [novu](01-automatizacion-mensajeria-crm.md#-novu) (notificaciones).
**Cómo encaja:** evolution-api recibe/envía mensajes vía webhook; n8n enruta y llama al LLM; chatwoot centraliza cuando entra un agente humano.

### 🎬 2. Pipeline de Reels / video corto
**Objetivo:** convertir contenido en video corto con voz y subtítulos.
**Stack:** [whisperX](12-audio-voz-video.md#-whisperx) (subtítulos alineados) + [supertonic](12-audio-voz-video.md#-supertonic) o [TTS](12-audio-voz-video.md#-tts) (voz) + [ComfyUI](11-generacion-de-imagen-vision.md#-comfyui) o [Fooocus](11-generacion-de-imagen-vision.md#-fooocus) (visuales) + [Real-ESRGAN](11-generacion-de-imagen-vision.md#-real-esrgan) (upscale) → [moviepy](12-audio-voz-video.md#-moviepy) o [remotion](12-audio-voz-video.md#-remotion) (ensamblaje) → [lossless-cut](12-audio-voz-video.md#-lossless-cut) (corte final).
**Cómo encaja:** [videofy_minimal](#-videofy_minimal) puede orquestar el flujo simple; remotion/moviepy escalan a variantes programáticas.

### 🔎 3. Agente de research profundo
**Objetivo:** investigación citada y estructurada a partir de la web.
**Stack:** [gpt-researcher](03-frameworks-orquestacion-de-agentes.md#-gpt-researcher) o [deer-flow](03-frameworks-orquestacion-de-agentes.md#-deer-flow) (orquestador) + [firecrawl](04-scraping-busqueda-research-web.md#-firecrawl) / [crawl4ai](04-scraping-busqueda-research-web.md#-crawl4ai) (extracción) + [browser-use](04-scraping-busqueda-research-web.md#-browser-use) (navegación) + [markitdown](13-documentos-presentaciones.md#-markitdown) (ingesta) + [langfuse](06-memoria-llm-ops-observabilidad.md#-langfuse) (trazas).

### 🏠 4. Workspace privado local soberano
**Objetivo:** asistente todo-en-uno sin fuga de datos.
**Stack:** [odysseus](08-workspaces-de-ia-local-notebooks.md#-odysseus) (workspace) + [open-notebook](08-workspaces-de-ia-local-notebooks.md#-open-notebook) (conocimiento) + [ECC](08-workspaces-de-ia-local-notebooks.md#-ecc) (control seguro de agentes) + Ollama (modelos) + [mem0](06-memoria-llm-ops-observabilidad.md#-mem0) (memoria).

### 🧠 5. Análisis de repos grandes
**Objetivo:** que un asistente entienda una base de código enorme barato.
**Stack:** [codegraph](07-inteligencia-de-codigo-datos-entrenamiento.md#-codegraph) (índice local) + [graphify](07-inteligencia-de-codigo-datos-entrenamiento.md#-graphify) / [graphrag](07-inteligencia-de-codigo-datos-entrenamiento.md#-graphrag) (grafo) + [GitNexus](07-inteligencia-de-codigo-datos-entrenamiento.md#-gitnexus) (exploración) + Claude Code.

### 📈 6. Marketing de agencia
**Objetivo:** operar campañas y contenido a escala.
**Stack:** [marketingskills](02-skills-prompts-guias-de-agente.md#-marketingskills) + [agency-agents](02-skills-prompts-guias-de-agente.md#-agency-agents) (playbooks) + [mautic](01-automatizacion-mensajeria-crm.md#-mautic) (automatización) + [listmonk](01-automatizacion-mensajeria-crm.md#-listmonk) (email) + [posthog](10-analitica-visualizacion.md#-posthog) / [metabase](10-analitica-visualizacion.md#-metabase) (analítica) + [Open-Generative-AI](11-generacion-de-imagen-vision.md#-open-generative-ai) (creativos).

### 🌐 7. Web app moderna con IA
**Objetivo:** construir frontend pulido rápido.
**Stack:** [open-design](09-diseno-ui-frontend.md#-open-design) o [plasmic](09-diseno-ui-frontend.md#-plasmic) (diseño→código) + [tailwindcss](09-diseno-ui-frontend.md#-tailwindcss) + [heroui](09-diseno-ui-frontend.md#-heroui) o [ui](09-diseno-ui-frontend.md#-ui-shadcn) (componentes) + [GSAP](09-diseno-ui-frontend.md#-gsap) / [motion](09-diseno-ui-frontend.md#-motion) / [three.js](09-diseno-ui-frontend.md#-threejs) (animación/3D) + [swr](09-diseno-ui-frontend.md#-swr) (datos) + [echarts](10-analitica-visualizacion.md#-echarts) / [uPlot](10-analitica-visualizacion.md#-uplot) (gráficos).

### 🔌 8. Construir una app/servidor MCP
**Objetivo:** exponer datos o herramientas propias a asistentes.
**Stack:** [mcp-use](05-mcp-conectividad.md#-mcp-use) (framework) + [mcp](05-mcp-conectividad.md#-mcp) (SDK) + [servers](05-mcp-conectividad.md#-servers) (ejemplos de referencia) + [awesome-mcp-servers](05-mcp-conectividad.md#-awesome-mcp-servers) (qué ya existe).

### 📊 9. Documentos → presentaciones
**Objetivo:** pasar texto/informes a slides editables.
**Stack:** [markitdown](13-documentos-presentaciones.md#-markitdown) (todo → Markdown limpio) → [ppt-master](13-documentos-presentaciones.md#-ppt-master) (PPTX) o [reveal.js](13-documentos-presentaciones.md#-revealjs) (slides web).

---
